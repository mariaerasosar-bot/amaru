# Amaru · Investor Pitch Deck

**Rituals rooted in the Americas.** The trusted marketplace for holistic rituals, tools and retreats. Pre-seed 2026.

This repository hosts the Amaru pitch deck as a website, published free with GitHub Pages.

## View the deck

- Live site: `https://<your-github-username>.github.io/amaru-pitch/`
- Jump to a slide: add `#` and the slide number, for example `.../amaru-pitch/#9` for Financials.
- PDF version: [AMARU-Investor-Pitch-Deck.pdf](AMARU-Investor-Pitch-Deck.pdf)

| Action | How |
| --- | --- |
| Next / previous slide | Arrow keys, space bar, click the right or left half of the screen, or swipe on a phone |
| First / last slide | Home / End |
| Full screen | `F` key or the ⛶ button |
| Save as PDF | Print the page from your browser and choose "Save as PDF" (one slide per page) |

## Publish it on GitHub (about 5 minutes, no coding)

1. Sign in at [github.com](https://github.com) and click **New repository**.
2. Name it `amaru-pitch`. Choose **Public**, because GitHub Pages is free only for public repositories. Then click **Create repository**.
3. On the new repository page, click **uploading an existing file**.
4. Unzip `amaru-pitch.zip` on your computer. Drag everything inside the `amaru-pitch` folder into the browser: `index.html`, `README.md`, `AMARU-Investor-Pitch-Deck.pdf` and the `img` and `fonts` folders. Then click **Commit changes**.
5. Go to **Settings → Pages**. Under **Build and deployment**, set **Source** to *Deploy from a branch*, choose the `main` branch and the `/ (root)` folder, and click **Save**.
6. Wait 1–2 minutes and refresh. GitHub shows your link: `https://<your-username>.github.io/amaru-pitch/`.

> A public repository means anyone with the link can see the deck. To share it only with selected investors, keep sending the PDF instead, or use a private host such as a private Artifact link or DocSend.

## Edit the deck

All the text is in `index.html`. Each slide is a `<section class="slide">` block with a comment that names it (`<!-- 9 · Financials -->`). On GitHub, open `index.html`, click the pencil icon, change the text and click **Commit changes**. The site updates in about a minute.

Replace these placeholders before sharing:

- Slide 10: Laura's career highlights and Daniel's last name.
- Slide 11: the SAFE valuation cap `[$__]`.

## Files

```
index.html                       the deck (HTML, CSS and navigation in one file)
img/                             slide photos
fonts/                           Cormorant Garamond and Jost (self-hosted, SIL Open Font License)
AMARU-Investor-Pitch-Deck.pdf    downloadable PDF
.nojekyll                        tells GitHub Pages to serve the files as they are
```

© 2026 Amaru. All rights reserved.
